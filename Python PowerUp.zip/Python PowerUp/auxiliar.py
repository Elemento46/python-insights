import pyautogui
import time

time.sleep(5)
print(pyautogui.position())

#         codigo       marca        tipo  categoria  preco_unitario  custo               obs
# 0    MOLO000251    Logitech       Mouse          1           25.95    6.5               NaN
# 1    MOLO000192    Logitech       Mouse          2           19.95    5.0               NaN
# 2    CAHA000251     Hashtag      Camisa          1           25.00   11.0               NaN
# 3    CAHA000252     Hashtag      Camisa          2           25.00   11.0  Conferir estoque
# 4    MOMU000111  Multilaser       Mouse          1           11.99    3.4               NaN
# ..          ...         ...         ...        ...             ...    ...               ...
# 288  ACAP000192       Apple  Acessorios          2           19.00    3.8               NaN
# 289  ACSA0009.3     Samsung  Acessorios          3            9.55    2.1               NaN
# 290  CEMO000271    Motorola     Celular          1          279.00   72.5               NaN
# 291  FOMO000152    Motorola        Fone          2          150.00   33.0               NaN
# 292  CEMO000223    Motorola     Celular          3          229.00   55.0               NaN